import{c as o}from"./chunk-4RY4XMBZ.js";var r=o("Geolocation",{web:()=>import("./chunk-BRT7Z34M.js").then(e=>new e.GeolocationWeb)});export{r as a};
